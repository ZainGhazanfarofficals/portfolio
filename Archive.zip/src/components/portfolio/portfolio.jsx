import { useRef } from "react";
import "./portfolio.scss";
import { motion, useScroll, useSpring, useTransform } from "framer-motion";
const items = [
  {
    id: 1,
    title: "Next Commerce",
    image:
      "https://images.pexels.com/photos/3063362/pexels-photo-3063362.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    desc: "Revolutionize your e-commerce with our Next.js-based platform—delivering blazing-fast performance and an intuitive, modern design. Elevate user satisfaction, drive conversions, and future-proof your online business.",
  },
  {
    id: 2,
    title: "Mind Morpheus",
    image:
      "https://images.pexels.com/photos/3045825/pexels-photo-3045825.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    desc: "Empower your education platform with our AI-driven course generator built on Next.js. Experience seamless content creation, dynamic personalization, and cutting-edge technology, enhancing the learning journey for students and educators alike.",
  },
  {
    id: 3,
    title: "Next Project Management",
    image:
      "https://images.pexels.com/photos/3705645/pexels-photo-3705645.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    desc: "Optimize project efficiency with our Next.js-powered Project Management solution. Enjoy intuitive collaboration, real-time updates, and a streamlined interface, empowering your team to achieve project success with cutting-edge technology.",
  },
  {
    id: 4,
    title: "Finance Tracker",
    image:
      "https://images.pexels.com/photos/3045828/pexels-photo-3045828.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    desc: "Transform your financial management with our Next.js-powered Finance Tracker. Experience real-time insights, secure transactions, and a user-friendly interface, ensuring smart and efficient control over your finances through advanced technology.",
  },
];
const Single = ({ item }) => {
  const ref = useRef();
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: [ "start start" , "end start" ],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "-300%"]);

  return (
    <section ref={ref}>
      <div className="container">
        <div className="wrapper">
          <div className="imageContainer">
            <img src={item.image} alt="" />
          </div>
          <motion.div className="textContainer" style={{y}}>
            <h2>{item.title}</h2>
            <p>{item.desc}</p>
            <button>See Demo</button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
function portfolio() {
  const ref = useRef();
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["end end", "start start"],
  });
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
  });
  return (
    <div className="portfolio" ref={ref}>
      <div className="progress">
        <h1>Featured Works</h1>
        <motion.div style={{ scaleX }} className="progressBar"></motion.div>
      </div>
      {items.map((item) => (
        <Single item={item} key={item.id} />
      ))}
    </div>
  );
}

export default portfolio;
